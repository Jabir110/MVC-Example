//
//  Category.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Category : NSObject

@property (nonatomic, strong) NSString *strCategoryName;
@property (nonatomic, strong) NSString *strCategoryImage;

+(Category *)initWithDictionary:(NSDictionary *)dictCategoryDetail;

@end
