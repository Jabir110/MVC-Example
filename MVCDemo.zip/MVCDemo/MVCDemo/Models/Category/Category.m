//
//  Category.m
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "Category.h"

@implementation Category

+(Category *)initWithDictionary:(NSDictionary *)dictCategoryDetail{

#if DEBUG
    NSLog(@"dictCategoryDetail %@",dictCategoryDetail);
#endif
    
    Category *CategoryDetail = [Category new];

    CategoryDetail.strCategoryName = [dictCategoryDetail valueForKey:@"category_name"];
    CategoryDetail.strCategoryImage = [dictCategoryDetail valueForKey:@"category_image"];
    
#if DEBUG
    NSLog(@"strCategoryName: %@",CategoryDetail.strCategoryName);
    NSLog(@"strCategoryImage: %@",CategoryDetail.strCategoryImage);
#endif

        return CategoryDetail;
}
@end
