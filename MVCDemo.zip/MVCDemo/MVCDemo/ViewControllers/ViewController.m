//
//  ViewController.m
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
 
    [SERVICE_MANAGER getCategoryListWithCompletionHandler:^(BOOL isSuccess, NSDictionary *dictResponse) {
        
        NSLog(@"strCategoryName: %@",[SERVICE_MANAGER.arrayCategoryList valueForKey:@"strCategoryName"]);
        NSLog(@"strCategoryImage: %@",[SERVICE_MANAGER.arrayCategoryList valueForKey:@"strCategoryImage"]);
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
