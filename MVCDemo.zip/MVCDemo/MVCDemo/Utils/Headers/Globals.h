//
//  Globals.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#ifndef Globals_h
#define Globals_h

#pragma mark - AppDelegate
#pragma mark -
//==========================
#import "AppDelegate.h"


#pragma mark - Header
#pragma mark - 
//==========================
#import "Macros.h"
#import "ServiceConstants.h"


#pragma mark - PODS
#pragma mark - 
//==========================
#import <AFNetworking/AFNetworking.h>
#import <SVProgressHUD/SVProgressHUD.h>


#pragma mark - Utils
#pragma mark - 
//==========================
#import "ServiceManager.h"
#import "HudUtils.h"

#pragma mark - MODELS
#pragma mark -
//==========================
#import "Category.h"


#endif /* Globals_h */
