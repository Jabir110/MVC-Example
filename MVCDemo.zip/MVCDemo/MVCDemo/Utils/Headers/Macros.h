//
//  Macros.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#ifndef Macros_h
#define Macros_h

#pragma mark - UTILITY MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
//////////////////////////// UTILITY MACROS ////////////////////////////
////////////////////////////////////////////////////////////////////////
#define SERVICE_MANAGER [ServiceManager sharedManager]
#define getValue(d, k) [d objectForKey:k]

#pragma mark - APP DELEGATE
#pragma mark -
////////////////////////////////////////////////////////////////////////
///////////////////////////// APP DELEGATE /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define appDelegate                                                            \
((AppDelegate *)[[UIApplication sharedApplication] delegate])

#pragma mark - DEVICE TYPE MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
////////////////////////// DEVICE TYPE MACROS //////////////////////////
////////////////////////////////////////////////////////////////////////
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_RETINA ([[UIScreen mainScreen] scale] >= 2.0)

#pragma mark - DEVICE DIMENSION MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
/////////////////////// DEVICE DIMENSION MACROS ////////////////////////
////////////////////////////////////////////////////////////////////////
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_4_OR_LESS (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)

////////////////////////////////////////////////////////////////////////
//////////////////// PROPORTIONAL DIMENSION MACROS /////////////////////
////////////////////////////////////////////////////////////////////////
#pragma mark - PROPORTIONAL DIMENSION MACROS
#pragma mark -
#define PROPORTIONAL_WIDTH(w) ((SCREEN_WIDTH * w)/750)
#define PROPORTIONAL_HEIGHT(h) ((SCREEN_HEIGHT * h)/1334)

#define PROPORTIONAL_WIDTH_CELL(w) ((SCREEN_WIDTH * w)/750)
#define PROPORTIONAL_HEIGHT_CELL(h) ((SCREEN_WIDTH * h)/1334)


#pragma mark - COLOR MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
///////////////////////////// COLOR MACROS /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define COLOR(r, g, b)                                                         \
[UIColor colorWithRed:(r / 255.0f)                                           \
green:(g / 255.0f)                                           \
blue:(b / 255.0f)                                           \
alpha:1.0]
#define COLOR_WITH_ALPHA(r, g, b, a)                                           \
[UIColor colorWithRed:(r / 255.0f)                                           \
green:(g / 255.0f)                                           \
blue:(b / 255.0f)                                           \
alpha:a / 1.0f];

#define PIXEL_COLOR                                                            \
[UIColor colorWithPatternImage:[UIImage imageNamed:@"bgPixel"]]
#define PIXEL_IMAGE [UIImage imageNamed:@"bgPixel"]

#define NAV_BAR_COLOR COLOR(48,52,63)
#define THEME_PINK_COLOR COLOR(252,0,82)
#define TEXT_FIELD_PLACEHOLDER_COLOR COLOR(136,136,136)
#define TEXT_FIELD_TEXT_COLOR COLOR(51,51,51)
#define SEPARATOR_COLOR COLOR(213,213,213)
#define BUTTON_BORDER_COLOR SEPARATOR_COLOR
#define BUTTON_BACKGROUND_COLOR COLOR(244,244,244)
#define BUTTON_TITLE_COLOR COLOR(119,119,119)
#define SEGMENT_CONTROL_BACKGROUND_COLOR COLOR(247,247,247)
#define SEGMENT_CONTROL_SELECTED_BACKGROUND_COLOR COLOR(221,221,221)

//#define THEME_GREEN_COLOR COLOR(0, 147, 133)
//#define THEME_LIGHT_GREEN_COLOR COLOR(36, 161, 149)
////#define THEME_DARK_GRAY_COLOR COLOR(99, 109, 108)
//#define THEME_DARK_GRAY_COLOR [UIColor darkGrayColor]
////#define THEME_DARK_GRAY_COLOR COLOR(73, 84, 89)
//#define THEME_YELLOW_COLOR COLOR(255, 182, 52)

#pragma mark - FONT MACROS
#pragma mark -
////////////////////////////////////////////////////////////////////////
////////////////////////////// FONT MACROS /////////////////////////////
////////////////////////////////////////////////////////////////////////
#define FONT_FAMILY_REGULAR @"CenturyGothic"
#define FONT_FAMILY_BOLD @"CenturyGothic-Bold"
#define FONT_FAMILY_SEMIBOLD @""

#define REGULAR_FONT(s)                                                        \
[UIFont fontWithName:FONT_FAMILY_REGULAR size:PROPORTIONAL_FONT_SIZE(s)]
#define BOLD_FONT(s)                                                           \
[UIFont fontWithName:FONT_FAMILY_BOLD size:PROPORTIONAL_FONT_SIZE(s)]
#define SEMI_BOLD_FONT(s)                                                      \
[UIFont fontWithName:FONT_FAMILY_SEMIBOLD size:PROPORTIONAL_FONT_SIZE(s)]

#define PROPORTIONAL_FONT_SIZE(s)                                              \
(s + (IS_IPHONE_4_OR_LESS ? -3 : 0) + (IS_IPHONE_5 ? -2 : 0) +                \
(IS_IPHONE_6 ? -1 : 0) + (IS_IPHONE_6P ? 0 : 0))


#pragma mark - VALIDATION MACROS
#pragma mark -

#define CONFIGURE_TEXT_FIELD_FOR_LENGHT_VALIDATIONS(t,min,max) ([t setUpTextFieldForLengthValidation:min maxLength:max])
#define CONFIGURE_TEXT_FIELD_FOR_PROPERTY(t,p) ([t attachTextFieldWithProperty:p])


#endif /* Macros_h */
