//
//  ServiceConstants.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#ifndef ServiceConstants_h
#define ServiceConstants_h

#define BASE_URL @"http://ohdeals.com/mobileapp/"

#define IS_INTERNET_AVAILABLE ([[AFNetworkReachabilityManager sharedManager] isReachable])

#define kAPICategoryList @"category_list.php"
#define kAPICity @"city.php"
#define kAPILogin @"login.php"

#define MAKE_URL(s) ([BASE_URL stringByAppendingString:s])

#endif /* ServiceConstants_h */
