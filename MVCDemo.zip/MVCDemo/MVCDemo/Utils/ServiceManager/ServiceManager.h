//
//  ServiceManager.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceManager : NSObject

@property(nonatomic, strong) AFHTTPSessionManager *manager;

#pragma mark - SINGLETON INSTANCE
#pragma mark -
+ (ServiceManager *)sharedManager;

#pragma mark - WEB SERVICE CLIENT
#pragma mark -
- (AFHTTPSessionManager *)webServiceClient;

#pragma mark - CATEGORY
#pragma mark -

-(void)getCategoryListWithCompletionHandler:(void (^)(BOOL isSuccess, NSDictionary *dictResponse))completionHandler;
@property (nonatomic,strong) NSMutableArray *arrayCategoryList;


@end
