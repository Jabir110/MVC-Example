//
//  ServiceManager.m
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "ServiceManager.h"
#define CLIENT [self webServiceClient]

@implementation ServiceManager

/////////////////////////////////////////////
///// ********** SINGLETON ************ /////
/////////////////////////////////////////////
#pragma mark - SINGLETON INSTANCE
#pragma mark -
+ (ServiceManager *)sharedManager {
    static dispatch_once_t pred = 0;
    __strong static ServiceManager *sharedManager = nil;
    dispatch_once(&pred, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}


//////////////////////////////////////////////
///// ******* WEB SERVICE CLIENT ******* /////
//////////////////////////////////////////////
#pragma mark - WEB SERVICE CLIENT
#pragma mark -
- (AFHTTPSessionManager *)webServiceClient {
    if (self.manager){
        return self.manager;
    }
    
    self.manager = [[AFHTTPSessionManager alloc]
                    initWithBaseURL:[NSURL URLWithString:BASE_URL]];
    
    self.manager.requestSerializer = [AFJSONRequestSerializer serializer];
    self.manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    NSMutableSet *acceptableContentTypes = [NSMutableSet setWithSet:self.manager.responseSerializer.acceptableContentTypes];
    if(![[acceptableContentTypes allObjects] containsObject:@"text/html"]){
        [acceptableContentTypes addObject:@"text/html"];
    }
    if(![[acceptableContentTypes allObjects] containsObject:@"application/json"]){
        [acceptableContentTypes addObject:@"application/json"];
    }
    self.manager.responseSerializer.acceptableContentTypes = acceptableContentTypes;
    
    return self.manager;
}


#pragma mark - CATEGORY LIST
#pragma mark -
-(void)getCategoryListWithCompletionHandler:(void (^)(BOOL isSuccess, NSDictionary *dictResponse))completionHandler{
    
    self.arrayCategoryList = [NSMutableArray new];

    [self getDataFromUrl:MAKE_URL(kAPICategoryList) params:nil withShowLoading:YES hideLoading:YES completionHandler:^(BOOL isSuccess, NSDictionary *dictResponse) {
        if(isSuccess){
            
            // PARSE THE ENTRY OPTIONS HERE . .
            
            id arrTimeZones = [dictResponse valueForKeyPath:@"data"];

            #if DEBUG
                NSLog(@"arrTimeZones: %@",arrTimeZones);
            #endif

            if([arrTimeZones isKindOfClass:[NSArray class]])
            {
                for (NSDictionary *dictTimeZone in arrTimeZones)
                {
                    #if DEBUG
                        NSLog(@"dictTimeZone: %@",dictTimeZone);
                    #endif
                    [self.arrayCategoryList addObject:[Category initWithDictionary:dictTimeZone]];
                }
            }            
//            NSLog(@"arrayCategoryList: %@",self.arrayCategoryList);
        }
        
        if(completionHandler)
            completionHandler(isSuccess,dictResponse);
    }];
}

#pragma mark - GET
#pragma mark -
- (void)getDataFromUrl:(NSString *)urlForGet
                params:(NSDictionary *)parameters
       withShowLoading:(BOOL)shouldShowLoader
           hideLoading:(BOOL)shouldHideLoader
     completionHandler:(void (^)(BOOL isSuccess,
                                 NSDictionary *dictResponse))completionHandler {
//    if (!IS_INTERNET_AVAILABLE) {
//        [AIHudUtils hideHUD];
//        [AIAlertUtils noInternet];
//        completionHandler(NO, nil);
//        //        return;
//    }
    
    if(shouldShowLoader){
        [HudUtils showHUD];
    }
    
    [CLIENT GET:urlForGet
     parameters:parameters
       progress:^(NSProgress *_Nonnull uploadProgress) {
           
       }
        success:^(NSURLSessionDataTask *_Nonnull task,
                  id _Nullable responseObject) {
            
            if(shouldHideLoader){
                [HudUtils hideHUD];
            }
            
#if DEBUG
            NSLog(@"==================================================");
            NSLog(@" URL %@  \n  PARAMS : %@  \n  "
                  @"RESPONSE : %@",
                  task.originalRequest.URL, parameters, responseObject);
#endif
            
            if (completionHandler) {
                completionHandler(YES, responseObject);
            }
            
//            [AIAlertUtils displayAlertWithMessage:@"Success" otherButtonTitles:nil preferredAlertStyle:UIAlertControllerStyleAlert withCompletion:nil];
            
        }
        failure:^(NSURLSessionDataTask *_Nullable task, NSError *_Nonnull error) {
            
            if(shouldHideLoader){
                [HudUtils hideHUD];
            }

#if DEBUG
            NSLog(@"==================================================");
            NSLog(@" URL %@  \n  PARAMS : %@  \n  ERROR : "
                  @"%@",
                  task.originalRequest.URL, parameters, error);
#endif
            if (completionHandler) {
                completionHandler(NO, nil);
            }
            
//            [AIAlertUtils displayAlertWithMessage:error.localizedDescription otherButtonTitles:nil preferredAlertStyle:UIAlertControllerStyleAlert withCompletion:nil];
            
        }];
}




@end
