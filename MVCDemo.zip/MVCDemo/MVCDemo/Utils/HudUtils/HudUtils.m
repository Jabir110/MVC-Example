//
//  HudUtils.m
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import "HudUtils.h"

@implementation HudUtils

#pragma mark - SETUP HUD
+ (void)configureHud {
    [SVProgressHUD setFont:REGULAR_FONT(16.0)];
    [SVProgressHUD setForegroundColor:THEME_PINK_COLOR];
    [SVProgressHUD setBackgroundColor:SEGMENT_CONTROL_BACKGROUND_COLOR];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeGradient];
}

#pragma mark - DISPLAY HUD
+ (void)showHUD {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [[self class] showHUDWithMessage:@"Please wait..."];
}

#pragma mark - DISPLAY HUD WITH MESSAGE
+ (void)showHUDWithMessage:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        //        [GiFHUD setGifWithImageName:@"loader.gif"];
        //        [GiFHUD showWithOverlay];
        [SVProgressHUD showWithStatus:message];
    });
}

#pragma mark - HIDE HUD
#pragma mark -
+ (void)hideHUD {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [SVProgressHUD dismiss];
        //        [GiFHUD dismiss];
    });
}

@end
