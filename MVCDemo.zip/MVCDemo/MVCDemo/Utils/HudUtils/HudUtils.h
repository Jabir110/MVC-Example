//
//  HudUtils.h
//  MVCDemo
//
//  Created by mackbook on 4/5/16.
//  Copyright © 2017 VirtualHeight. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HudUtils : NSObject

#pragma mark - SETUP HUD
#pragma mark -
+ (void)configureHud;

#pragma mark - DISPLAY HUD
#pragma mark -
+ (void)showHUD;
+ (void)showHUDWithMessage:(NSString *)message;

#pragma mark - HIDE HUD
#pragma mark -
+ (void)hideHUD;

@end
